# AgroLink Nigeria — MVP starter

A mobile-friendly farmer-to-buyer marketplace prototype built with React + Vite. It includes:
- Product search, category filters and location filter
- Product cards with direct WhatsApp contact when a real seller phone is available
- Farmer advert submission form
- Proposed advert subscription plans
- Optional Supabase listing read/submit integration
- Supabase schema with public read limited to approved, unexpired listings

## Important status: prototype, not production-ready
The example product cards are clearly labelled SAMPLE and are not real verified offers. The demo form works only in the browser session unless Supabase is configured. Subscription selection does not collect payment or activate adverts. The bank details are intentionally not embedded in public source code.

## Run locally
1. Install Node.js (LTS) from https://nodejs.org/
2. Unzip this folder.
3. In this folder run:
   ```bash
   npm install
   npm run dev
   ```
4. Open the local URL printed by Vite.

## Add Supabase
1. Create a project at https://supabase.com/
2. In the Supabase SQL Editor, run `supabase/schema.sql`.
3. Copy `.env.example` to `.env.local`.
4. Add your Supabase project URL and anon/public key to `.env.local`.
5. Restart `npm run dev`.

The anon key is designed to be used in the browser with RLS enabled. Never add the `service_role` key to `.env.local` or any variable prefixed with `VITE_`.

## Deploy to Vercel
1. Create a GitHub repository and upload the contents of this folder.
2. In https://vercel.com/, import that repository.
3. Vercel normally detects Vite. Build command: `npm run build`; output directory: `dist`.
4. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in Vercel Project Settings → Environment Variables, then redeploy.
5. Test on a phone and computer.

## Before accepting farmers or payments
- Replace sample listings with real listings and remove demo data from `src/main.jsx`.
- Add farmer authentication and ownership checks so users can edit only their own adverts.
- Add image upload using Supabase Storage with safe file limits and policies.
- Add admin-only approval/rejection and subscription expiry management using a protected server-side function.
- Add payment instructions only after privately configuring and verifying the receiving account. Manually verify bank transfers before activating adverts.
- Add spam protection/rate limits, privacy notice, terms, reporting process and backup plan.
- Test that anonymous users cannot update listings, approve adverts, see unapproved listings or access admin functions.

## Subscription plans
Starter prices in the UI are placeholders for validation: ₦500 / 7 days, ₦1,500 / 30 days and ₦3,000 / 30 days. Change them after speaking with farmers and buyers.

## Bank details
Do not place bank account information in frontend code, GitHub, or VITE_ environment variables. For an initial launch, provide verified bank-transfer details only through a controlled admin process and confirm transfers manually. A production payment workflow should use a trusted provider or server-side process.
