-- AgroLink Nigeria starter schema.
-- Run this in Supabase SQL Editor after creating a project.
-- Before launch, configure authentication, test RLS policies and create a private admin review workflow.

create extension if not exists pgcrypto;

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 2 and 120),
  category text not null,
  price numeric(14,2) not null check (price > 0),
  unit text not null default 'per item',
  location text not null,
  quantity text,
  seller_name text not null,
  seller_phone text not null,
  description text,
  image_url text,
  status text not null default 'pending' check (status in ('pending','approved','rejected','expired')),
  expires_at timestamptz not null default (now() + interval '7 days'),
  created_at timestamptz not null default now()
);

create index if not exists listings_public_search_idx on public.listings (status, expires_at, created_at desc);
create index if not exists listings_category_idx on public.listings (category);
create index if not exists listings_location_idx on public.listings (location);

alter table public.listings enable row level security;

-- Public visitors can only read approved, unexpired listings.
create policy "Public can read approved active listings"
on public.listings for select
to anon, authenticated
using (status = 'approved' and expires_at > now());

-- Initial demo submission policy. This permits public submissions only as pending.
-- Add rate limiting / CAPTCHA and authentication before a public production launch.
create policy "Visitors can submit pending listings"
on public.listings for insert
to anon, authenticated
with check (status = 'pending');

-- Intentionally no public update/delete policies.
-- Admin approval and subscription activation must use a protected server/admin process.
-- Never expose the Supabase service_role key in browser code.
