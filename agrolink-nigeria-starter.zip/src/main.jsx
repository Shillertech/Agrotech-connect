import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import { Search, MapPin, Sprout, MessageCircle, ShieldCheck, Wheat, ChevronDown, PlusCircle, Menu, X, ArrowRight, CheckCircle2 } from 'lucide-react';
import './styles.css';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

const demoProducts = [
  { id: 'demo-1', title: 'Fresh Yellow Maize', category: 'Grains', price: 65000, unit: 'per 100kg bag', location: 'Ile-Ife, Osun', quantity: 'Available in bulk', seller_name: 'Ade Farms', seller_phone: '', description: 'Clean, dry maize suitable for food processing and animal feed.', image_url: 'https://images.unsplash.com/photo-1551754655-cd27e38d2076?auto=format&fit=crop&w=900&q=80', is_demo: true },
  { id: 'demo-2', title: 'Fresh Cassava', category: 'Tubers', price: 18000, unit: 'per tonne', location: 'Iwo, Osun', quantity: 'Harvest to order', seller_name: 'Bola Agro', seller_phone: '', description: 'Fresh cassava roots for garri, flour and other processing.', image_url: 'https://images.unsplash.com/photo-1596097635121-14b63b7a0c19?auto=format&fit=crop&w=900&q=80', is_demo: true },
  { id: 'demo-3', title: 'Fresh Eggs', category: 'Livestock & Poultry', price: 5200, unit: 'per crate', location: 'Ilorin, Kwara', quantity: '100+ crates available', seller_name: 'Green Nest Poultry', seller_phone: '', description: 'Farm-fresh table eggs. Bulk buyers welcome.', image_url: 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?auto=format&fit=crop&w=900&q=80', is_demo: true },
  { id: 'demo-4', title: 'Red Onions', category: 'Vegetables', price: 42000, unit: 'per 100kg bag', location: 'Kano, Kano', quantity: 'Limited stock', seller_name: 'Northern Harvest', seller_phone: '', description: 'Red onions for retailers, restaurants and wholesalers.', image_url: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?auto=format&fit=crop&w=900&q=80', is_demo: true },
  { id: 'demo-5', title: 'Fresh Catfish', category: 'Livestock & Poultry', price: 3500, unit: 'per kg', location: 'Ibadan, Oyo', quantity: 'Fresh harvest available', seller_name: 'AquaGrow Farms', seller_phone: '', description: 'Freshly harvested catfish. Contact seller to confirm size and quantity.', image_url: 'https://images.unsplash.com/photo-1510130387422-82bed34b37e9?auto=format&fit=crop&w=900&q=80', is_demo: true },
  { id: 'demo-6', title: 'Palm Oil', category: 'Processed Farm Products', price: 48000, unit: 'per 25-litre keg', location: 'Akure, Ondo', quantity: 'Small and bulk orders', seller_name: 'Sunrise Agro', seller_phone: '', description: 'Locally processed palm oil. Confirm packaging and current price.', image_url: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=900&q=80', is_demo: true }
];
const categories = ['All products', 'Grains', 'Tubers', 'Vegetables', 'Fruits', 'Livestock & Poultry', 'Processed Farm Products', 'Farm Inputs'];
const plans = [
  { name: 'Starter', price: '₦500', period: '7 days', detail: '1 product listing', features: ['One active advert', 'WhatsApp enquiries', '7-day listing period'] },
  { name: 'Grower', price: '₦1,500', period: '30 days', detail: 'Up to 5 listings', features: ['Up to five active adverts', 'WhatsApp enquiries', '30-day listing period'], popular: true },
  { name: 'Commercial', price: '₦3,000', period: '30 days', detail: 'Up to 15 listings', features: ['Up to fifteen active adverts', 'WhatsApp enquiries', '30-day listing period'] }
];
const naira = n => '₦' + Number(n || 0).toLocaleString('en-NG');

function App() {
  const [products, setProducts] = useState(demoProducts);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All products');
  const [location, setLocation] = useState('');
  const [showFarmer, setShowFarmer] = useState(false);
  const [showPlans, setShowPlans] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const [form, setForm] = useState({ title: '', category: 'Grains', price: '', unit: 'per bag', location: '', quantity: '', seller_name: '', seller_phone: '', description: '' });

  const visible = useMemo(() => products.filter(p => {
    const text = `${p.title} ${p.category} ${p.location} ${p.seller_name} ${p.description}`.toLowerCase();
    return text.includes(query.toLowerCase()) &&
      (category === 'All products' || p.category === category) &&
      p.location.toLowerCase().includes(location.toLowerCase());
  }), [products, query, category, location]);

  async function loadListings() {
    if (!supabase) return;
    const { data, error } = await supabase.from('listings').select('*').eq('status', 'approved').gt('expires_at', new Date().toISOString()).order('created_at', { ascending: false });
    if (error) { setNotice('Could not load live listings. Check your Supabase setup.'); return; }
    setProducts([...(data || []), ...demoProducts]);
  }

  React.useEffect(() => { loadListings(); }, []);

  async function submitListing(e) {
    e.preventDefault();
    const cleanPhone = form.seller_phone.replace(/\D/g, '');
    const listing = { ...form, price: Number(form.price), seller_phone: cleanPhone, status: 'pending', is_demo: false };
    if (!form.title || !form.price || !form.location || !form.seller_name || cleanPhone.length < 10) {
      setNotice('Please complete the required fields and enter a valid phone number.'); return;
    }
    if (supabase) {
      const { error } = await supabase.from('listings').insert([{ ...listing, expires_at: new Date(Date.now() + 7*86400000).toISOString() }]);
      if (error) { setNotice('Listing was not submitted. Ensure you have configured the database policies.'); return; }
      setNotice('Your advert has been submitted for review. It will appear after admin approval.');
    } else {
      setProducts(prev => [{ ...listing, id: `local-${Date.now()}`, image_url: '', is_demo: false }, ...prev]);
      setNotice('Demo only: your advert is visible in this browser session. Connect Supabase before real use.');
    }
    setShowFarmer(false);
    setForm({ title: '', category: 'Grains', price: '', unit: 'per bag', location: '', quantity: '', seller_name: '', seller_phone: '', description: '' });
  }

  function contactSeller(p) {
    if (!p.seller_phone) { setNotice('This sample listing has no seller contact. Replace demo listings with verified farmer adverts before launch.'); return; }
    const phone = p.seller_phone.startsWith('0') ? '234' + p.seller_phone.slice(1) : p.seller_phone;
    const message = encodeURIComponent(`Hello ${p.seller_name}, I found your "${p.title}" advert on AgroLink Nigeria. Is it still available?`);
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank', 'noopener,noreferrer');
  }

  return <div className="app">
    <div className="topbar"><div className="container topbar-inner"><span><Sprout size={15}/> Connecting Nigerian farms to buyers</span><span className="top-note">A marketplace for farm produce and agricultural supplies</span></div></div>
    <header className="header"><div className="container nav">
      <a className="brand" href="#" aria-label="AgroLink home"><span className="brand-mark"><Wheat size={25}/></span><span>AgroLink<span className="brand-accent"> Nigeria</span><small>FROM FARM TO MARKET</small></span></a>
      <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen ? <X/> : <Menu/>}</button>
      <nav className={menuOpen ? 'nav-links open' : 'nav-links'}><a href="#market" onClick={() => setMenuOpen(false)}>Explore produce</a><a href="#how" onClick={() => setMenuOpen(false)}>How it works</a><a href="#plans" onClick={() => {setShowPlans(true);setMenuOpen(false)}}>Advertise</a><button className="btn btn-primary nav-cta" onClick={() => {setShowFarmer(true);setMenuOpen(false)}}><PlusCircle size={17}/> Post a product</button></nav>
    </div></header>

    <main>
      <section className="hero"><div className="container hero-grid"><div className="hero-copy">
        <div className="eyebrow"><span className="eyebrow-dot"></span> YOUR MARKETPLACE FOR AGRICULTURE</div>
        <h1>Good produce.<br/><em>Better connections.</em></h1>
        <p>Discover farm produce, compare offers and connect directly with farmers and suppliers across Nigeria.</p>
        <div className="hero-actions"><button className="btn btn-primary btn-large" onClick={() => document.getElementById('market').scrollIntoView({behavior:'smooth'})}>Explore marketplace <ArrowRight size={18}/></button><button className="btn btn-outline btn-large" onClick={() => setShowFarmer(true)}>I'm a farmer</button></div>
        <div className="trust-line"><ShieldCheck size={17}/> Direct seller contact · No buyer commission</div>
      </div><div className="hero-art"><div className="hero-photo"></div><div className="floating-card"><span className="float-icon"><CheckCircle2 size={20}/></span><div><strong>Direct farmer contact</strong><small>Talk to sellers before you buy</small></div></div><div className="hero-stamp"><Sprout size={25}/><span>Grown with purpose</span></div></div></div></section>

      <section className="search-wrap"><div className="container search-panel"><div className="search-field"><Search size={20}/><input aria-label="Search products" placeholder="What are you looking for? e.g. maize, eggs, cassava" value={query} onChange={e=>setQuery(e.target.value)}/></div><div className="search-field location-field"><MapPin size={19}/><input aria-label="Filter by location" placeholder="State, town or area" value={location} onChange={e=>setLocation(e.target.value)}/></div><button className="btn btn-primary search-button" onClick={()=>document.getElementById('market').scrollIntoView({behavior:'smooth'})}>Find products</button></div></section>

      <section className="market section" id="market"><div className="container"><div className="section-heading"><div><span className="eyebrow">THE MARKETPLACE</span><h2>Explore farm products</h2><p>Browse offers and contact sellers to confirm price, quality and availability.</p></div><button className="text-button" onClick={()=>{setCategory('All products');setQuery('');setLocation('')}}>Clear filters <ArrowRight size={15}/></button></div>
        <div className="category-row">{categories.map(c=><button key={c} className={category===c?'category active':'category'} onClick={()=>setCategory(c)}>{c}</button>)}</div>
        <div className="results-meta"><span><strong>{visible.length}</strong> listings to explore</span><span className="demo-warning">Sample listings shown until live farmer adverts are added</span></div>
        <div className="product-grid">{visible.map(p=><article className="product-card" key={p.id}><div className="product-image">{p.image_url ? <img src={p.image_url} alt={p.title} loading="lazy"/> : <div className="image-placeholder"><Sprout size={42}/></div>}<span className="product-category">{p.category}</span>{p.is_demo && <span className="sample-tag">SAMPLE</span>}</div><div className="product-content"><div className="product-location"><MapPin size={14}/>{p.location}</div><h3>{p.title}</h3><p className="product-description">{p.description || 'Contact the seller for more details.'}</p><div className="product-price">{naira(p.price)} <small>{p.unit}</small></div><div className="stock">{p.quantity || 'Ask seller for availability'}</div><div className="seller-row"><div className="seller-avatar">{(p.seller_name||'F').slice(0,1).toUpperCase()}</div><div className="seller-name"><strong>{p.seller_name || 'Local farmer'}</strong><small>Product supplier</small></div><button className="contact-btn" onClick={()=>contactSeller(p)} aria-label={`Contact ${p.seller_name}`}><MessageCircle size={17}/></button></div><button className="btn btn-contact" onClick={()=>contactSeller(p)}>Contact seller <ArrowRight size={15}/></button></div></article>)}</div>
        {visible.length===0 && <div className="empty"><Sprout size={35}/><h3>No products found</h3><p>Try another search term or remove a filter.</p><button className="btn btn-outline" onClick={()=>{setQuery('');setCategory('All products');setLocation('')}}>Reset search</button></div>}
      </div></section>

      <section className="how section" id="how"><div className="container"><div className="center-heading"><span className="eyebrow">SIMPLE BY DESIGN</span><h2>Trade directly. Keep it clear.</h2><p>AgroLink helps people discover opportunities; buyers and sellers agree on the transaction themselves.</p></div><div className="steps"><div className="step"><span className="step-num">01</span><div className="step-icon"><Search/></div><h3>Find what you need</h3><p>Search by product, category or location to find suitable offers.</p></div><div className="step"><span className="step-num">02</span><div className="step-icon"><MessageCircle/></div><h3>Talk to the seller</h3><p>Ask about quantity, quality, delivery and the current price directly.</p></div><div className="step"><span className="step-num">03</span><div className="step-icon"><Sprout/></div><h3>Agree and trade</h3><p>Confirm terms independently before paying or arranging collection.</p></div></div></div></section>

      <section className="advertise section" id="plans"><div className="container advertise-inner"><div><span className="eyebrow">FOR FARMERS & SUPPLIERS</span><h2>Let more buyers discover your produce.</h2><p>Post an advert, show your price and location, and receive enquiries directly. Subscription pricing is a proposed starting point and can be changed before launch.</p><button className="btn btn-light btn-large" onClick={()=>setShowPlans(true)}>View advert plans <ArrowRight size={17}/></button></div><div className="advertise-graphic"><div className="ad-graphic-circle"><Wheat size={76}/></div><div className="ad-mini-card"><CheckCircle2 size={17}/> Your next buyer could be here</div></div></div></section>

      <section className="safety section"><div className="container safety-inner"><ShieldCheck size={28}/><div><h3>Buy and sell with care</h3><p>Sample listings are illustrative only. Always verify the seller, inspect goods when possible, agree on delivery terms and confirm payment details independently. AgroLink does not guarantee product quality or facilitate produce payments.</p></div></div></section>
    </main>
    <footer className="footer"><div className="container footer-inner"><a className="brand footer-brand" href="#"><span className="brand-mark"><Wheat size={23}/></span><span>AgroLink<span className="brand-accent"> Nigeria</span><small>FROM FARM TO MARKET</small></span></a><p>Helping Nigerian farmers connect with the people who need their produce.</p><span className="copyright">© {new Date().getFullYear()} AgroLink Nigeria · Built for agriculture</span></div></footer>

    {notice && <div className="toast" role="status"><span>{notice}</span><button onClick={()=>setNotice('')} aria-label="Dismiss"><X size={16}/></button></div>}

    {showFarmer && <div className="modal-backdrop" onClick={()=>setShowFarmer(false)}><section className="modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setShowFarmer(false)} aria-label="Close"><X/></button><span className="eyebrow">SELL ON AGROLINK</span><h2>Post a product advert</h2><p className="modal-intro">Submit your details. Live submissions require Supabase configuration and admin approval.</p><form className="farmer-form" onSubmit={submitListing}>
      <label>Product name *<input required value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="e.g. Fresh maize"/></label>
      <div className="form-two"><label>Category *<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{categories.slice(1).map(c=><option key={c}>{c}</option>)}</select></label><label>Price in naira *<input required type="number" min="1" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} placeholder="e.g. 25000"/></label></div>
      <div className="form-two"><label>Unit / package<input value={form.unit} onChange={e=>setForm({...form,unit:e.target.value})} placeholder="per bag, crate, kg..."/></label><label>Quantity available<input value={form.quantity} onChange={e=>setForm({...form,quantity:e.target.value})} placeholder="e.g. 20 bags"/></label></div>
      <label>Location (town and state) *<input required value={form.location} onChange={e=>setForm({...form,location:e.target.value})} placeholder="e.g. Iwo, Osun"/></label>
      <div className="form-two"><label>Your name / farm name *<input required value={form.seller_name} onChange={e=>setForm({...form,seller_name:e.target.value})} placeholder="Farm or business name"/></label><label>WhatsApp number *<input required value={form.seller_phone} onChange={e=>setForm({...form,seller_phone:e.target.value})} placeholder="e.g. 08012345678"/></label></div>
      <label>Description<textarea rows="3" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Quality, packaging, bulk orders, harvest date..."/></label>
      <div className="form-note"><ShieldCheck size={17}/> In the launch version, adverts should be reviewed before publication. Do not submit sensitive personal or banking information.</div>
      <button className="btn btn-primary btn-large full-btn" type="submit">Submit advert for review <ArrowRight size={17}/></button>
    </form></section></div>}

    {showPlans && <div className="modal-backdrop" onClick={()=>setShowPlans(false)}><section className="modal plans-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setShowPlans(false)} aria-label="Close"><X/></button><span className="eyebrow">ADVERT SUBSCRIPTIONS</span><h2>Choose a listing plan</h2><p className="modal-intro">Proposed prices for testing demand. These are not payment-enabled yet; start with manual review and activation.</p><div className="plan-grid">{plans.map(plan=><article key={plan.name} className={`plan-card ${plan.popular?'popular':''}`}>{plan.popular&&<span className="popular-label">POPULAR</span>}<h3>{plan.name}</h3><p>{plan.detail}</p><div className="plan-price">{plan.price}<small> / {plan.period}</small></div><ul>{plan.features.map(f=><li key={f}><CheckCircle2 size={15}/>{f}</li>)}</ul><button className={`btn ${plan.popular?'btn-primary':'btn-outline'} full-btn`} onClick={()=>{setShowPlans(false);setNotice('Subscription checkout is not connected yet. Configure admin payment verification before accepting transfers.')}}>Select plan</button></article>)}</div><p className="small-print">Important: Do not transfer money based on this demo. The live bank details, payment instructions and admin approval workflow must be configured before launch.</p></section></div>}
  </div>;
}

createRoot(document.getElementById('root')).render(<App />);
